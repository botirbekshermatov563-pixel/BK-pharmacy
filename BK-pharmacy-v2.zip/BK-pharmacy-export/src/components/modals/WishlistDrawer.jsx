import React from 'react';
import { useTranslation } from '../../i18n';
import { useCart } from '../../context/CartContext';
import { useWishlist } from '../../context/WishlistContext';
import { X, Heart, Trash2, Plus, Check, ShoppingBag } from 'lucide-react';

export const WishlistDrawer = ({ settings }) => {
  const { lang, t } = useTranslation();
  const { cart, addToCart, setSelectedProduct } = useCart();
  const {
    wishlist,
    isWishlistOpen,
    setIsWishlistOpen,
    removeFromWishlist,
    clearWishlist
  } = useWishlist();

  if (!isWishlistOpen) return null;

  const handleClose = () => setIsWishlistOpen(false);

  const handleView = (product) => {
    setSelectedProduct(product);
    handleClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/60 backdrop-blur-xs flex justify-end animate-fade-in" onClick={handleClose}>
      <div
        className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col justify-between border-l border-slate-100"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center">
              <Heart className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 font-display">
                {t('wishlist_title')}
              </h3>
              <span className="text-xs text-slate-500">
                {wishlist.length} {t('wishlist_items_count')}
              </span>
            </div>
          </div>

          <button
            onClick={handleClose}
            className="w-9 h-9 rounded-full bg-white hover:bg-slate-200 text-slate-500 hover:text-slate-800 flex items-center justify-center transition-colors cursor-pointer border border-slate-200"
            aria-label="Close wishlist"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-5">
          {wishlist.length > 0 ? (
            <div className="space-y-4">
              {wishlist.map((item) => {
                const cartItem = cart.find((c) => c.id === item.id);
                const inCartCount = cartItem ? cartItem.quantity : 0;
                return (
                  <div
                    key={item.id}
                    className="p-3.5 rounded-2xl bg-[#fbfdfc] border border-slate-200/80 flex items-center gap-3 group"
                  >
                    <img
                      src={item.image_url}
                      alt={lang === 'uz' ? item.name_uz : item.name_ru}
                      onClick={() => handleView(item)}
                      className="w-14 h-14 object-contain rounded-xl bg-white p-1 border border-slate-100 shrink-0 cursor-pointer"
                    />

                    <div className="flex-1 min-w-0">
                      <h4
                        onClick={() => handleView(item)}
                        className="text-xs sm:text-sm font-bold text-slate-900 truncate cursor-pointer hover:text-emerald-700 transition-colors"
                      >
                        {lang === 'uz' ? item.name_uz : item.name_ru}
                      </h4>
                      <div className="text-xs font-black text-slate-900 font-display mt-1">
                        {Number(item.price).toLocaleString()} {t('currency')}
                      </div>
                    </div>

                    {/* Add to cart */}
                    <button
                      onClick={() => addToCart(item)}
                      className={`w-9 h-9 shrink-0 rounded-xl flex items-center justify-center transition-colors cursor-pointer ${
                        inCartCount > 0
                          ? 'bg-emerald-100 text-emerald-700 border border-emerald-300'
                          : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                      }`}
                      title={t('btn_add_to_cart')}
                    >
                      {inCartCount > 0 ? <Check className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                    </button>

                    {/* Remove */}
                    <button
                      onClick={() => removeFromWishlist(item.id)}
                      className="text-slate-400 hover:text-rose-600 p-1 transition-colors cursor-pointer"
                      title={t('btn_remove_from_wishlist')}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                );
              })}

              <button
                onClick={clearWishlist}
                className="text-xs text-rose-500 hover:text-rose-700 font-medium py-1 transition-colors"
              >
                {t('wishlist_btn_clear')}
              </button>
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
              <div className="w-16 h-16 rounded-full bg-rose-50 text-rose-500 flex items-center justify-center">
                <Heart className="w-8 h-8" />
              </div>
              <h4 className="text-lg font-bold text-slate-800 font-display">
                {t('wishlist_empty_title')}
              </h4>
              <p className="text-xs text-slate-500 max-w-xs leading-relaxed">
                {t('wishlist_empty_desc')}
              </p>
              <button
                onClick={handleClose}
                className="px-6 py-2.5 rounded-xl bg-emerald-600 text-white text-xs font-bold shadow-md hover:bg-emerald-700 transition-all cursor-pointer flex items-center gap-2"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>{t('hero_btn_catalog')}</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
